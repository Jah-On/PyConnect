# -*- coding: utf-8 -*-
"""
AutoPy is a simple, cross-platform GUI automation library for Python.
"""

from . import key, mouse

__author__ = "Michael Sanders"
__version__ = "4.0.0"
__all__ = ["key", "mouse"]
